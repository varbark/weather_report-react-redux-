import React, { Component } from 'react'
import { connect } from 'react-redux'
import { getWeather } from '../../redux/actions/index'

class Weather extends Component{
  constructor(props) {
    super(props)
  }
  render() {
    const {city_code, info:{loading, condition, location}, onGetWeather} = this.props;
    return(
      <div>
        <button onClick={onGetWeather}>台北市</button>
        <br/>CountStatus: 
        <span style={{color:"blue"}}>
            {loading}</span>
        <p/>
        <WeatherInfo condition={condition} location={location}/>
      </div>
    )
  }
}

function WeatherInfo(props) {
    if(props.location.city){
      return (
          <div>
            <h4>地點：{props.location.city}</h4>
            <p>氣溫：{props.condition.temp}</p>
            <p>天氣：{props.condition.text}</p>
          </div>
      )
    }else{
      return(
        <div></div>
        )
    }
}

export default connect(
  (state, ownProps) =>( {
    info: state.examples.weather
  }),
  {onGetWeather: () => getWeather}
)(Weather)